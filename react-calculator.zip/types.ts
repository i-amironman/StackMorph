
export enum ActionType {
    ADD_DIGIT = 'add-digit',
    CHOOSE_OPERATION = 'choose-operation',
    CLEAR = 'clear',
    DELETE_DIGIT = 'delete-digit',
    CALCULATE = 'calculate',
}

export enum Operator {
    ADD = '+',
    SUBTRACT = '-',
    MULTIPLY = '×',
    DIVIDE = '÷',
}
