
import React, { useState, useCallback } from 'react';
import Calculator from './components/Calculator';
import { ActionType, Operator } from './types';

const App: React.FC = () => {
  const [currentOperand, setCurrentOperand] = useState<string>('0');
  const [previousOperand, setPreviousOperand] = useState<string | null>(null);
  const [operation, setOperation] = useState<Operator | null>(null);
  const [overwrite, setOverwrite] = useState<boolean>(true);

  const evaluate = useCallback((): string => {
    const prev = parseFloat(previousOperand || '0');
    const current = parseFloat(currentOperand);
    if (isNaN(prev) || isNaN(current)) return '';
    let computation = 0;
    switch (operation) {
      case Operator.ADD:
        computation = prev + current;
        break;
      case Operator.SUBTRACT:
        computation = prev - current;
        break;
      case Operator.MULTIPLY:
        computation = prev * current;
        break;
      case Operator.DIVIDE:
        if (current === 0) return 'Error';
        computation = prev / current;
        break;
      default:
        return currentOperand;
    }
    return computation.toString();
  }, [currentOperand, previousOperand, operation]);

  const handleAction = useCallback((type: ActionType, payload: string) => {
    switch (type) {
      case ActionType.ADD_DIGIT:
        if (overwrite) {
          setCurrentOperand(payload);
          setOverwrite(false);
          return;
        }
        if (payload === '0' && currentOperand === '0') return;
        if (payload === '.' && currentOperand.includes('.')) return;
        setCurrentOperand(`${currentOperand}${payload}`);
        break;

      case ActionType.CHOOSE_OPERATION:
        if (currentOperand === 'Error') return;
        if (previousOperand != null) {
          const result = evaluate();
          setPreviousOperand(result);
          setCurrentOperand(result);
        } else {
          setPreviousOperand(currentOperand);
        }
        setOperation(payload as Operator);
        setOverwrite(true);
        break;
        
      case ActionType.CALCULATE:
        if (operation == null || previousOperand == null || currentOperand === 'Error') {
          return;
        }
        const result = evaluate();
        setCurrentOperand(result);
        setPreviousOperand(null);
        setOperation(null);
        setOverwrite(true);
        break;

      case ActionType.CLEAR:
        setCurrentOperand('0');
        setPreviousOperand(null);
        setOperation(null);
        setOverwrite(true);
        break;

      case ActionType.DELETE_DIGIT:
        if (overwrite || currentOperand === 'Error') {
          setCurrentOperand('0');
          setOverwrite(true);
          return;
        }
        if (currentOperand.length === 1) {
          setCurrentOperand('0');
          setOverwrite(true);
          return;
        }
        setCurrentOperand(currentOperand.slice(0, -1));
        break;
    }
  }, [currentOperand, previousOperand, operation, overwrite, evaluate]);

  return (
    <div className="min-h-screen bg-gray-900 flex flex-col items-center justify-center font-mono">
        <h1 className="text-4xl font-bold text-white mb-8">React Calculator</h1>
        <Calculator
            currentOperand={currentOperand}
            previousOperand={previousOperand}
            operation={operation}
            handleAction={handleAction}
        />
    </div>
  );
};

export default App;
