
import React from 'react';
import { Operator } from '../types';

interface DisplayProps {
  currentOperand: string;
  previousOperand: string | null;
  operation: Operator | null;
}

const formatOperand = (operand: string | null) => {
  if (operand == null) return "";
  if (operand === 'Error') return "Error";
  const [integer, decimal] = operand.split('.');
  if (decimal == null) return new Intl.NumberFormat('en-US', { maximumFractionDigits: 0 }).format(parseFloat(integer));
  return `${new Intl.NumberFormat('en-US', { maximumFractionDigits: 0 }).format(parseFloat(integer))}.${decimal}`;
};

const Display: React.FC<DisplayProps> = ({ currentOperand, previousOperand, operation }) => {
  const isError = currentOperand === 'Error';
  const displayValue = formatOperand(currentOperand);
  const fontSizeClass = displayValue.length > 9 ? 'text-4xl' : 'text-6xl';

  return (
    <div className="bg-gray-900 text-white p-6 flex flex-col items-end justify-around break-words break-all">
      <div className="h-8 text-2xl text-gray-400">
        {formatOperand(previousOperand)} {operation}
      </div>
      <div className={`h-16 font-bold transition-font-size duration-100 ${isError ? 'text-red-500 text-4xl' : fontSizeClass}`}>
        {displayValue}
      </div>
    </div>
  );
};

export default Display;
