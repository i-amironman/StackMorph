
import React from 'react';
import Button from './Button';
import Display from './Display';
import { ActionType, Operator } from '../types';

interface CalculatorProps {
  currentOperand: string;
  previousOperand: string | null;
  operation: Operator | null;
  handleAction: (type: ActionType, payload: string) => void;
}

const Calculator: React.FC<CalculatorProps> = ({ currentOperand, previousOperand, operation, handleAction }) => {
  return (
    <div className="w-full max-w-sm mx-auto bg-black rounded-2xl shadow-2xl overflow-hidden border-4 border-gray-700">
      <Display
        currentOperand={currentOperand}
        previousOperand={previousOperand}
        operation={operation}
      />
      <div className="grid grid-cols-4 gap-px bg-gray-800">
        <Button onClick={() => handleAction(ActionType.CLEAR, 'AC')} className="bg-gray-600 hover:bg-gray-700 col-span-2">AC</Button>
        <Button onClick={() => handleAction(ActionType.DELETE_DIGIT, 'DEL')} className="bg-gray-600 hover:bg-gray-700">DEL</Button>
        <Button onClick={() => handleAction(ActionType.CHOOSE_OPERATION, Operator.DIVIDE)} className="bg-orange-500 hover:bg-orange-600">{Operator.DIVIDE}</Button>
        
        <Button onClick={() => handleAction(ActionType.ADD_DIGIT, '7')}>7</Button>
        <Button onClick={() => handleAction(ActionType.ADD_DIGIT, '8')}>8</Button>
        <Button onClick={() => handleAction(ActionType.ADD_DIGIT, '9')}>9</Button>
        <Button onClick={() => handleAction(ActionType.CHOOSE_OPERATION, Operator.MULTIPLY)} className="bg-orange-500 hover:bg-orange-600">{Operator.MULTIPLY}</Button>
        
        <Button onClick={() => handleAction(ActionType.ADD_DIGIT, '4')}>4</Button>
        <Button onClick={() => handleAction(ActionType.ADD_DIGIT, '5')}>5</Button>
        <Button onClick={() => handleAction(ActionType.ADD_DIGIT, '6')}>6</Button>
        <Button onClick={() => handleAction(ActionType.CHOOSE_OPERATION, Operator.SUBTRACT)} className="bg-orange-500 hover:bg-orange-600">{Operator.SUBTRACT}</Button>
        
        <Button onClick={() => handleAction(ActionType.ADD_DIGIT, '1')}>1</Button>
        <Button onClick={() => handleAction(ActionType.ADD_DIGIT, '2')}>2</Button>
        <Button onClick={() => handleAction(ActionType.ADD_DIGIT, '3')}>3</Button>
        <Button onClick={() => handleAction(ActionType.CHOOSE_OPERATION, Operator.ADD)} className="bg-orange-500 hover:bg-orange-600">{Operator.ADD}</Button>
        
        <Button onClick={() => handleAction(ActionType.ADD_DIGIT, '0')} className="col-span-2">0</Button>
        <Button onClick={() => handleAction(ActionType.ADD_DIGIT, '.')}>.</Button>
        <Button onClick={() => handleAction(ActionType.CALCULATE, '=')} className="bg-orange-500 hover:bg-orange-600">=</Button>
      </div>
    </div>
  );
};

export default Calculator;
