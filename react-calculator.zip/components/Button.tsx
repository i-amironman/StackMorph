
import React from 'react';

interface ButtonProps {
  onClick: () => void;
  children: React.ReactNode;
  className?: string;
}

const Button: React.FC<ButtonProps> = ({ onClick, children, className }) => {
  const baseClasses = "text-white text-3xl p-6 focus:outline-none transition-colors duration-200";
  const defaultBg = "bg-gray-700 hover:bg-gray-800";
  
  return (
    <button onClick={onClick} className={`${baseClasses} ${className || defaultBg}`}>
      {children}
    </button>
  );
};

export default Button;
