import React from 'react';
import { FilterType } from '../types.ts';

interface FilterControlsProps {
  currentFilter: FilterType;
  onFilterChange: (filter: FilterType) => void;
}

const FilterButton: React.FC<{
  filterType: FilterType;
  currentFilter: FilterType;
  onClick: (filter: FilterType) => void;
  children: React.ReactNode;
}> = ({ filterType, currentFilter, onClick, children }) => {
  const isActive = currentFilter === filterType;
  const baseClasses = 'px-4 py-2 rounded-md text-sm font-medium transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 dark:focus:ring-offset-slate-800';
  const activeClasses = 'bg-blue-600 text-white';
  const inactiveClasses = 'bg-white dark:bg-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-600';
  
  return (
    <button
      onClick={() => onClick(filterType)}
      className={`${baseClasses} ${isActive ? activeClasses : inactiveClasses}`}
    >
      {children}
    </button>
  );
};

const FilterControls: React.FC<FilterControlsProps> = ({ currentFilter, onFilterChange }) => {
  return (
    <div className="flex justify-center gap-2 mb-6 p-2 bg-slate-200 dark:bg-slate-800 rounded-lg">
      <FilterButton filterType="all" currentFilter={currentFilter} onClick={onFilterChange}>All</FilterButton>
      <FilterButton filterType="active" currentFilter={currentFilter} onClick={onFilterChange}>Active</FilterButton>
      <FilterButton filterType="completed" currentFilter={currentFilter} onClick={onFilterChange}>Completed</FilterButton>
    </div>
  );
};

export default FilterControls;