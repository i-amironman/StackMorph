import React, { useState, useMemo, useEffect } from 'react';
import { Todo, FilterType } from './types.ts';
import TodoInput from './components/TodoInput.tsx';
import TodoList from './components/TodoList.tsx';
import FilterControls from './components/FilterControls.tsx';

const App: React.FC = () => {
  const [todos, setTodos] = useState<Todo[]>(() => {
    try {
      const items = window.localStorage.getItem('todos');
      return items ? JSON.parse(items) : [];
    } catch (error) {
      console.error("Error reading from localStorage", error);
      return [];
    }
  });
  
  const [filter, setFilter] = useState<FilterType>('all');

  useEffect(() => {
    try {
      window.localStorage.setItem('todos', JSON.stringify(todos));
    } catch (error) {
      console.error("Error writing to localStorage", error);
    }
  }, [todos]);

  const addTodo = (text: string) => {
    const newTodo: Todo = {
      id: Date.now(),
      text,
      completed: false,
    };
    setTodos((prevTodos) => [newTodo, ...prevTodos]);
  };

  const toggleTodo = (id: number) => {
    setTodos((prevTodos) =>
      prevTodos.map((todo) =>
        todo.id === id ? { ...todo, completed: !todo.completed } : todo
      )
    );
  };

  const deleteTodo = (id: number) => {
    setTodos((prevTodos) => prevTodos.filter((todo) => todo.id !== id));
  };

  const filteredTodos = useMemo(() => {
    if (filter === 'active') {
      return todos.filter((todo) => !todo.completed);
    }
    if (filter === 'completed') {
      return todos.filter((todo) => todo.completed);
    }
    return todos;
  }, [todos, filter]);

  const activeCount = useMemo(() => todos.filter(t => !t.completed).length, [todos]);

  return (
    <div className="min-h-screen flex items-start justify-center p-4 sm:p-6 lg:p-8">
      <div className="w-full max-w-2xl mx-auto">
        <header className="text-center my-8">
          <h1 className="text-4xl sm:text-5xl font-extrabold text-slate-800 dark:text-white tracking-tight">
            Todo List
          </h1>
          <p className="mt-2 text-slate-500 dark:text-slate-400">
            A simple and elegant way to manage your tasks.
          </p>
        </header>

        <main className="bg-white dark:bg-slate-800/50 backdrop-blur-sm rounded-xl shadow-2xl p-6 sm:p-8">
          <TodoInput onAddTodo={addTodo} />
          <FilterControls currentFilter={filter} onFilterChange={setFilter} />
          <div className="border-t border-slate-200 dark:border-slate-700 pt-6">
            <TodoList
              todos={filteredTodos}
              onToggle={toggleTodo}
              onDelete={deleteTodo}
            />
          </div>
           <footer className="mt-6 pt-4 border-t border-slate-200 dark:border-slate-700 text-center text-sm text-slate-500 dark:text-slate-400">
            <p>{activeCount} {activeCount === 1 ? 'task' : 'tasks'} left</p>
          </footer>
        </main>
      </div>
    </div>
  );
};

export default App;